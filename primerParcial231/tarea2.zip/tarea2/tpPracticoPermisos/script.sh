#!/bin/bash
echo "Por favor, ingrese su nombre"
read nombre
echo "Hola, $nombre , bienvenide "
#Contenido del scrip
echo "Este es el contenido"
cat script.sh

