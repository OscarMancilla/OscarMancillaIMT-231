#!/bin/bsh
Este  es un script de prueba
