#!/bin/bash
pwd
cd /tmp
ls
cd ~
mkdir practica_shell
cd practica_shell
pwd 

