#include <stdio.h>

int esPar(int n) {

    return n % 2 == 0;
}

int main() {
    int numero;
    while (1) {

        printf("Ingrese un número (-1 para salir): ");

        scanf("%d", &numero);
        if (numero == -1) 
		break;
        if (esPar(numero))
            printf("Es par.\n");
        else
            printf("Es impar.\n");
    }
    return 0;
}
