#include <stdio.h>

int contarDigitos(int n) {
    int contador = 0;
    do {
        contador++;
        n /= 10;
    } while (n > 0);
    return contador;
}

int main() {
    int numero;
    while (1) {
        printf("Ingrese un número positivo (0 para salir): ");
        scanf("%d", &numero);
        if (numero == 0)
	 break;
        printf("Tiene %d dígitos.\n", contarDigitos(numero));
    }
    return 0;
}

