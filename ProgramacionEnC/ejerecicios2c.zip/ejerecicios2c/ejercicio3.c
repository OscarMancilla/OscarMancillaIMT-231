#include <stdio.h>

typedef enum { ROJO, VERDE, AMARILLO } Semaforo;

int main() {
    Semaforo estado = ROJO;
    for (int i = 0; i < 10; i++) {
        switch (estado) {
            case ROJO:     printf("Semáforo ROJO\n");     estado = VERDE; break;
            case VERDE:    printf("Semáforo VERDE\n");    estado = AMARILLO; break;
            case AMARILLO: printf("Semáforo AMARILLO\n"); estado = ROJO; break;
        }
    }
    return 0;
}
