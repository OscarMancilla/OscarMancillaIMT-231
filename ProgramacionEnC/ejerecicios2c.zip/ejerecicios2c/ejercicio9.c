#include <stdio.h>

int invertir(int n) {
    int invertido = 0;
    while (n > 0) {
        invertido = invertido * 10 + n % 10;
        n /= 10;
    }
    return invertido;
}

int main() {
    int numero;
    while (1) {
        printf("Ingrese un número (>9 para continuar): ");
        scanf("%d", &numero);
        if (numero < 10) 
		break;
        printf("Invertido: %d\n", invertir(numero));
    }
    return 0;
}
