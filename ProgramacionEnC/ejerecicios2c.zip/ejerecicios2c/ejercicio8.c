#include <stdio.h>

int factorial(int n) {
    int resultado = 1;
    for (int i = 1; i <= n; i++) 
		resultado *= i;
    return resultado;
}

int main() {
    int numero;
    while (1) {
        printf("Ingrese un número positivo (<=0 para salir): ");
        scanf("%d", &numero);
        if (numero <= 0)
	     break;
        printf("Factorial: %d\n", factorial(numero));
    }
    return 0;
}
