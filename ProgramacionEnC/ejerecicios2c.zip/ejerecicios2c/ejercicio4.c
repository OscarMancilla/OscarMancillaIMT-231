#include <stdio.h>

int main() {
    int numero, suma = 0;
    while (1) {
        printf("Ingrese un número positivo (negativo para salir): ");
        scanf("%d", &numero);
        if (numero < 0) 
		break;
        suma += numero;
    }
    printf("Suma total: %d\n", suma);
    return 0;
}
