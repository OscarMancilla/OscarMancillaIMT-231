#include <stdio.h>

int sumar(int a, int b) { return a + b; }
int restar(int a, int b) { return a - b; }
int multiplicar(int a, int b) { return a * b; }

int main() {
    int opcion, x, y;
    while (1) {
        printf("1. Sumar\n2. Restar\n3. Multiplicar\n4. Salir\nOpción: ");
        scanf("%d", &opcion);
        if (opcion == 4)
	 break;
        printf("Ingrese dos números: ");
        scanf("%d %d", &x, &y);
        switch (opcion) {
            case 1: 
		printf("Resultado: %d\n", sumar(x, y)); break;
            case 2: 
		printf("Resultado: %d\n", restar(x, y)); break;
            case 3: 
		printf("Resultado: %d\n", multiplicar(x, y)); break;
            default: 
		printf("Opción inválida.\n");
        }
    }
    return 0;
}
