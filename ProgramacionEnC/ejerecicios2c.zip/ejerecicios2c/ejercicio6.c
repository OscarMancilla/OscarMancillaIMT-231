#include <stdio.h>

void comparar(int a, int b) {
    if (a > b) printf("%d es mayor que %d\n", a, b);
    else if (b > a) printf("%d es mayor que %d\n", b, a);
    else printf("Ambos son iguales\n");
}

int main() {
    int a, b;
    while (1) {
        printf("Ingrese dos números (0 0 para salir): ");
        scanf("%d %d", &a, &b);
        if (a == 0 && b == 0) break;
        comparar(a, b);
    }
    return 0;
}
